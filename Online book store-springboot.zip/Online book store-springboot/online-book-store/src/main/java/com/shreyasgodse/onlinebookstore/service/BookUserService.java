package com.shreyasgodse.book_store.service;

import java.util.Set;

import com.shreyasgodse.book_store.entity.Book;
import com.shreyasgodse.book_store.entity.Customer;

public interface BookUserService {

	Set<Book> getBooksPurchasedBy(Customer customer);

}
