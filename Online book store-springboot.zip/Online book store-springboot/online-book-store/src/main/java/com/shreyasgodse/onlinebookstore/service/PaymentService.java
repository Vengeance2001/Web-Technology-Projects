package com.shreyasgodse.book_store.service;

import java.util.Set;

import com.shreyasgodse.book_store.entity.Customer;
import com.shreyasgodse.book_store.entity.PurchaseDetail;
import com.shreyasgodse.book_store.entity.PurchaseHistory;

public interface PaymentService {

	String createTransaction(Customer customer);
	
	Set<PurchaseHistory> getPurchaseHistories(Customer customer);
	
	Set<PurchaseDetail> getPurchaseDetails(PurchaseHistory purchaseHistory);

	PurchaseHistory getPurchaseHistory(Customer customer, String transId);
}
