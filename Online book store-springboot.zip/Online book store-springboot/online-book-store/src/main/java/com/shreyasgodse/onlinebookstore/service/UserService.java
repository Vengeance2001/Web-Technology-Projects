package com.shreyasgodse.book_store.service;

import java.util.List;

import com.shreyasgodse.book_store.entity.User;

public interface UserService {

	public List<User> getAllUsers();
	
	public User getUserByUsername(String username);
}
