package com.shreyasgodse.book_store.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shreyasgodse.book_store.entity.Customer;
import com.shreyasgodse.book_store.forms.entity.ChangePassword;
import com.shreyasgodse.book_store.forms.entity.CustomerData;
import com.shreyasgodse.book_store.entity.User;

public interface CustomerService {

	public List<Customer> getAllCustomers();
	
	public Customer getCustomer(String username);
		
	public String saveCustomer(Customer theCustomer);
	
	public String updateCustomer(Customer theCustomer);
	
	public String removeCustomer(Customer theCustomer);
	
	public String registerCustomer(CustomerData data);

	public CustomerData getCustomerData(String username);

	public String updateCustomer(CustomerData customerData);
	
	public String updatePassword(ChangePassword changePassword);
	
}
